package com.srm.core.repository;

public interface TestRepository {
    String get();
}
